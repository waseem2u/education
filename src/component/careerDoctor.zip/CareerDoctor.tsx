import React from "react";
import Image from "next/image";
import CareerCard from "./CareerCard";
import CareerInnovate from "./CareerInnovate";
import { CareerPlay, CareerStroke, TotalPoint, TotalDuration } from "@/svg";
import CareerCustomButton from "./CareerCustomButton";

const CareerDoctor = () => {
  //  const [inputChange, setInputChange] = useState("");
  return (
    <div className="px-4 md:px-16 lg:px-40 mt-4">
      <div className="flex justify-start items-center">
        <div className="w-full max-w-[1192px] h-[474px] flex justify-center items-center">
          <div className="max-w-[443px] h-full bg-purple-heart rounded-l-lg relative">
            <Image
              src="/careerImage/wave.png"
              alt="wave"
              width={443}
              height={309}
              className="absolute right-0 top-0"
            />
            <div className="px-2 py-8 lg:px-[74px] lg:py-[76px] flex justify-center items-start flex-col gap-9">
              <div>
                <h5 className="text-white font-space-gori font-normal text-2xl lg:text-[32px] ">
                  Explore Your Career Path
                </h5>
                <p className="text-base text-light-grey">
                  Nunc sed id semper risus in hendrerit gravida rutrum. Auctor
                  augue mauris augue neque gravida in fermentum et. Et ligula
                  ullamcorper{" "}
                </p>
              </div>
              <div className="flex justify-start items-start flex-col gap-[14px]">
                {CAREER_EXPLORE.map((x, index) => (
                  <div className="flex justify-start items-start gap-4">
                    {x.icon}
                    <p className="text-white font-space-gori font-normal">
                      {x.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-natural-grey rounded-r-lg h-full overflow-hidden">
            <video className=" h-full" controls>
              <source
                src="https://docs.material-tailwind.com/demo.mp4"
                type="video/mp4"
              />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </div>
      <div className="vertical-bar pl-4 lg:pl-16 top-4">
        {/* mobile screen */}
        {CAREER_D0CTOR.map((x, index) => (
          <div key={index} className="relative block md:hidden">
            <div className="absolute -left-6 top-[4px] lg:-left-20  lg:top-[1px] w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full"></div>
            <div className="">
              <div className=" w-full max-w-[1132px] flex justify-between items-center border-b border-natural-grey py-6">
                <div className=" flex justify-center items-center flex-col gap-2">
                  <div className="flex justify-center items-center gap-2 ">
                    <div className="flex justify-center items-center gap-1">
                      <div className="w-6 h-6 lg:w-[30px] lg:h-[30px] border border-purple-heart rounded-full flex justify-center items-center">
                        {x.image}
                      </div>

                      <span className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                        {x.id}
                      </span>
                    </div>
                    <p className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                      {x.name}
                    </p>
                  </div>
                  <div className="flex justify-center items-center gap-1">
                    <div className="flex justify-center items-center rounded-lg bg-off-green">
                      <p className=" text-base lg:text-base font-semibold text-caribbean-green px-2 py-2 text-center lg:px-4 lg:py-[10px]">
                        {x.percent}
                      </p>
                    </div>
                    <div>
                      <span className="text-base lg:text-base font-space-gori font-semibold text-blue-grey">
                        {x.minute}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        
        <div className="relative">
          <div className="absolute -left-6 lg:-left-20 top-8 lg:top-7 w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full"></div>
          <div className="">
            <div className=" w-full max-w-[1132px] flex justify-between items-center border-b border-natural-grey py-6">
              <div className=" flex justify-center items-center gap-14">
                <div className="flex justify-center items-center gap-2 ">
                  <div className="hidden lg:block">
                    <Image
                      src="/career/careerLamp.svg"
                      alt="career"
                      width={30}
                      height={30}
                    />
                  </div>
                  <div className="lg:hidden">
                    <Image
                      src="/career/careerLamp.svg"
                      alt="career"
                      width={24}
                      height={24}
                    />
                  </div>

                  <p className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                    Quiz
                  </p>
                </div>
                <div className="flex justify-center items-center rounded-lg bg-off-green"></div>
              </div>
              <div>
                <span className="text-xs lg:text-base font-space-gori font-semibold text-blue-grey">
                  10 Questions
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="pt-4">
          <CareerCard />
        </div>
        <div className=" w-full max-w-[1132px] flex justify-between items-center border-b border-natural-grey py-6">
          <div className="relative">
            <div className="absolute -left-6 lg:-left-20 top-[3px] lg:top-0 w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full"></div>
            <div className="">
              <div className="flex justify-center items-center gap-2">
                <div className="hidden lg:block">
                  <Image
                    src="/career/careerLamp.svg"
                    alt="career"
                    width={30}
                    height={30}
                  />
                </div>
                <div className="lg:hidden">
                  <Image
                    src="/career/careerLamp.svg"
                    alt="career"
                    width={24}
                    height={24}
                  />
                </div>
                <p className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                  Quiz
                </p>
              </div>
            </div>
          </div>
          <div>
            <span className="text-xs lg:text-base font-space-gori font-semibold text-[#697585]">
              10 Questions
            </span>
          </div>
        </div>
        <div className="pt-4">
          <div className="w-full max-w-[1132px] card-shadow">
            <div className="px-4 py-4">
              <div className="flex justify-start items-start flex-col gap-5">
                <div className="flex justify-start items-start">
                  <p className="text-base font-space-gori font-normal text-dark-pastel-purple">
                    Question:
                  </p>
                  <span className="text-base font-space-gori font-normal text-dark-pastel-purple">
                    3/30
                  </span>
                </div>
                <p className="text-xl font-space-gori font-normal text-ship-grey">
                  Who is the innovate bulb?
                </p>
              </div>
              <div className="pt-4 ">
                <div className=" border rounded px-[10px] pt-[10px] pb-[108px]">
                  <input
                    type="text"
                    placeholder="Type Your Answer"
                    className="placeholder:text-base lg:placeholder:text-lg placeholder:font-space-gori placeholder:text-silver-chalice"
                  />
                </div>
              </div>
              <div className="flex justify-start items-start gap-4 pt-6">
                <CareerCustomButton
                  name="Previous"
                  className="bg-voilet text-purple-heart"
                />
                <CareerCustomButton name="Next" className="text-white" />
              </div>
            </div>
          </div>
          {/* <CareerInnovate /> */}
        </div>

        {CAREER_D0CTOR.map((x, index) => (
          <div key={index} className="relative block md:hidden">
            <div className="absolute -left-6 top-[4px] lg:-left-20  lg:top-[1px] w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full"></div>
            <div className="">
              <div className=" w-full max-w-[1132px] flex justify-between items-center border-b border-natural-grey py-6">
                <div className=" flex justify-center items-center flex-col gap-2">
                  <div className="flex justify-center items-center gap-2 ">
                    <div className="flex justify-center items-center gap-1">
                      <div className="w-6 h-6 lg:w-[30px] lg:h-[30px] border border-purple-heart rounded-full flex justify-center items-center">
                        {x.image}
                      </div>

                      <span className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                        {x.id}
                      </span>
                    </div>
                    <p className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                      {x.name}
                    </p>
                  </div>
                  <div className="flex justify-center items-center gap-1">
                    <div className="flex justify-center items-center rounded-lg bg-off-green">
                      <p className=" text-base lg:text-base font-semibold text-caribbean-green px-2 py-2 text-center lg:px-4 lg:py-[10px]">
                        {x.percent}
                      </p>
                    </div>
                    <div>
                      <span className="text-base lg:text-base font-space-gori font-semibold text-blue-grey">
                        {x.minute}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}

        {CAREER_PART.map((x, index) => (
          <div key={index} className="relative hidden md:block">
            <div className="absolute -left-6 lg:-left-20 top-8 lg:top-7 w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full"></div>
            <div className="">
              <div className=" w-full max-w-[1132px] flex justify-between items-center border-b border-natural-grey py-6">
                <div className=" flex justify-center items-center gap-2 lg:gap-14">
                  <div className="flex justify-center items-center gap-2 ">
                    <div className="w-6 h-6 lg:w-[30px] lg:h-[30px] border border-purple-heart rounded-full flex justify-center items-center">
                      {x.image}
                    </div>

                    <span className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                      {x.count}
                    </span>
                    <p className="text-base lg:text-xl font-space-gori font-normal text-nile-blue">
                      {x.name}
                    </p>
                  </div>
                  <div className="flex justify-center items-center rounded-lg bg-off-green">
                    <p className="text-xs lg:text-base font-semibold text-caribbean-green px-1 py-2 lg:px-4 lg:py-[10px] text-center">
                      {x.percent}
                    </p>
                  </div>
                </div>
                <div>
                  <span className="text-xs lg:text-base font-space-gori font-semibold text-blue-grey">
                    {x.minute}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
        <div className="relative">
          <div className="absolute -left-6 lg:-left-20 top-[39px] lg:top-7 w-4 h-4 lg:w-[32px] lg:h-[32px] stars-shadow border border-light-violet rounded-full flex justify-center items-center">
            <div className="w-3 h-3 rounded-full bg-purple-heart"></div>
          </div>
          <div className="">
            <p className="text-lg lg:text-[28px] font-space-gori font-normal text-purple-heart pt-8">
              Congratulation! You Have Completed Path
            </p>
          </div>
        </div>
      </div>
      <div className="w-full max-w-[802px] flex justify-start items-start ">
        <p className="text-base lg:text-xl font-space-gori text-silver-chalice pt-4 pl-4 lg:pl-16">
          From interactive lessons to thought-provoking quizzes, everything at
          MojiGurukul is designed with your curiosity, excitement, and growth in
          mind.
        </p>
      </div>
    </div>
  );
};
export default CareerDoctor;
export const CAREER_D0CTOR = [
  {
    id: 1,
    image: <CareerPlay />,
    count: "1.",
    name: "Introduction of Doctor Career",
    percent: " 20% completed",
    minute: "10 minutes",
  },
  {
    id: 1,
    image: <CareerPlay />,
    count: "2.",
    name: "Introduction of Doctor Career",
    percent: " 20% completed",
    minute: "10 minutes",
  },
  {
    id: 2,
    image: <CareerPlay />,
    count: "3.",
    name: "Introduction of Doctor Career",
    percent: " 30% completed ",
    minute: "10 minutes",
  },
  {
    id: 3,
    image: <CareerPlay />,
    count: "4.",
    name: "Introduction of Doctor Career",
    percent: " 40% completed",
    minute: "10 minutes",
  },
  {
    id: 4,
    image: <CareerPlay />,
    count: "5.",
    name: "Introduction of Doctor Career",
    percent: " 50% completed",
    minute: "10 minutes",
  },
];
const CAREER_PART = [
  {
    id: 1,
    image: <CareerPlay />,
    count: "6.",
    name: "Introduction of Doctor Career",
    percent: " 10% Completed",
    minute: "10 minutes",
  },
  {
    id: 2,
    image: <CareerPlay />,
    count: "7.",
    name: "Introduction of Doctor Career",
    percent: " 10% Completed",
    minute: "10 minutes",
  },
  {
    id: 3,
    image: <CareerPlay />,
    count: "8.",
    name: "Introduction of Doctor Career",
    percent: " 10% Completed",
    minute: "10 minutes",
  },
];
const CAREER_EXPLORE = [
  {
    id: 1,
    icon: <CareerStroke />,
    detail: " Career Level",
  },
  {
    id: 2,
    icon: <TotalPoint />,
    detail: "Total Point : 80",
  },
  {
    id: 3,
    icon: <TotalDuration />,
    detail: "Duration : 8 segment Total 80 Minutes",
  },
];
